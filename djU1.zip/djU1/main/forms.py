from django.contrib.auth.forms import UserCreationForm
from custom_user.models import User
from django import forms
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout
from django.contrib.auth.forms import AuthenticationForm
from django.forms.widgets import PasswordInput, TextInput
from django import forms


class RegistrationForm(UserCreationForm):
    email = forms.EmailField(required=True)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['email'].widget.attrs['autocomplete'] = 'off'
        self.fields['password1'].widget.attrs['autocomplete'] = 'off'
        self.fields['password2'].widget.attrs['autocomplete'] = 'off'
        self.helper = FormHelper()
        self.helper.attrs = {'autocomplete': 'off'}
        self.helper.form_tag = False
        self.helper.disable_csrf = True
        self.helper.layout = Layout(*self.fields.keys())

    class Meta:
        model = User
        fields = ('email', 'password1', 'password2')


class LoginForm(AuthenticationForm):
    email = forms.CharField(required=True, widget=TextInput())
    password = forms.CharField(required=True, widget=PasswordInput())
