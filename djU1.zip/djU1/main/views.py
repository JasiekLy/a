from django.shortcuts import render, redirect
from .forms import RegistrationForm, LoginForm
from custom_user.models import User
from django.contrib.auth.models import auth
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required

# Create your views here.
def index(request):
    return render(request, 'main/index.html')

def user_register(request):
    form = RegistrationForm()

    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('user-login')

    context = {'form': form}

    return render(request, 'main/user-register.html', context)


def user_login(request):
    print('user login request called')
    form = LoginForm()
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data.get('email')
            password = form.cleaned_data.get('password')
            user = authenticate(request, email=email, password=password)
            if user is not None:
                auth.login(request, user)
                return redirect('dash')

    context = {'form_l': form}
    return render(request, 'main/user-login.html', context=context)

def user_logout(request):
    auth.logout(request)
    return redirect('')

def profilemanagement(request):
    return render(request, 'main/profilemanagement.html')

@login_required(login_url='user-login')
def dash(request):
    return render(request, 'main/dash.html')
