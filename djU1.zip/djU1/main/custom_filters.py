from django import template

register = template.Library()

@register.filter
def disable_autocomplete(field):
    field.field.widget.attrs.update({'autocomplete': 'off'})
    return field